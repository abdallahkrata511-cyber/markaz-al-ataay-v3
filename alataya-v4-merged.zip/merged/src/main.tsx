import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import {initStorage} from './services/sqliteStore';

// نُهيّئ قاعدة SQLite (ونرحّل بيانات النسخة القديمة إن وُجدت) قبل رسم الواجهة.
initStorage()
  .catch((e) => console.error('Storage init error:', e))
  .finally(() => {
    createRoot(document.getElementById('root')!).render(
      <StrictMode>
        <App />
      </StrictMode>,
    );
  });
